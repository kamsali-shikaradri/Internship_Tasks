# Problem 12: Capitalize!
# https://www.hackerrank.com/challenges/capitalize/problem

s = input()

words = s.split(" ")
result = " ".join(
    word[:1].upper() + word[1:] if word else ""
    for word in words
)

print(result)