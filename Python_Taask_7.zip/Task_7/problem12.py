# Problem: Making Anagrams
# HackerRank: https://www.hackerrank.com/challenges/making-anagrams/problem

from collections import Counter

s1 = input().strip()
s2 = input().strip()

count1 = Counter(s1)
count2 = Counter(s2)

deletions = sum((count1 - count2).values()) + sum((count2 - count1).values())
print(deletions)
