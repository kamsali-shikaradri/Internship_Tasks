# Problem: The Captain's Room
# HackerRank: https://www.hackerrank.com/challenges/py-the-captains-room/problem

k = int(input())
rooms = list(map(int, input().split()))

room_sum = sum(rooms)
unique_sum = sum(set(rooms))
print((k * unique_sum - room_sum) // (k - 1))
