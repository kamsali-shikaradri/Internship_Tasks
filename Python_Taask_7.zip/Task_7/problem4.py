# Problem: Funny String
# HackerRank: https://www.hackerrank.com/challenges/funny-string/problem

def is_funny(s):
    values = [ord(c) for c in s]
    reverse_values = [ord(c) for c in s[::-1]]

    for i in range(1, len(s)):
        if abs(values[i] - values[i - 1]) != abs(reverse_values[i] - reverse_values[i - 1]):
            return "Not Funny"
    return "Funny"

t = int(input())
for _ in range(t):
    print(is_funny(input().strip()))
