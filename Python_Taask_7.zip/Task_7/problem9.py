# Problem: Beautiful Binary String
# HackerRank: https://www.hackerrank.com/challenges/beautiful-binary-string/problem

n = int(input())
b = input().strip()

changes = 0
for i in range(len(b) - 2):
    if b[i:i + 3] == "010":
        changes += 1

print(changes)
