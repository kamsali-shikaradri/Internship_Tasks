# Problem: CamelCase
# HackerRank: https://www.hackerrank.com/challenges/camelcase/problem

s = input().strip()
if not s:
    print(0)
else:
    words = 1 + sum(1 for char in s if char.isupper())
    print(words)
