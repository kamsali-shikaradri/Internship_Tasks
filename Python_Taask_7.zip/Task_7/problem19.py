# Problem: Weighted Uniform Strings
# HackerRank: https://www.hackerrank.com/challenges/weighted-uniform-string/problem

s = input().strip()
n = int(input())
queries = [int(input()) for _ in range(n)]

weights = set()
previous = ""
run_length = 0

for char in s:
    if char == previous:
        run_length += 1
    else:
        previous = char
        run_length = 1

    weight = (ord(char) - ord("a") + 1) * run_length
    weights.add(weight)

for value in queries:
    print("Yes" if value in weights else "No")
