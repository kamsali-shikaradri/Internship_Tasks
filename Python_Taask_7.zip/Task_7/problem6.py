# Problem: Pangrams
# HackerRank: https://www.hackerrank.com/challenges/pangrams/problem

s = input().lower()
letters = {char for char in s if char.isalpha()}

print("pangram" if len(letters) == 26 else "not pangram")
