# Task 3: Python Coding & Problem-Solving
# Each function returns its result instead of printing it.

def q1_word_frequency(sentence):
    """Q1. Return the frequency of each word in a sentence."""
    frequency = {}
    for word in sentence.split():
        word = word.lower()
        frequency[word] = frequency.get(word, 0) + 1
    return frequency


def q2_character_frequency(word):
    """Q2. Return the frequency of each character in a word."""
    frequency = {}
    for char in word:
        frequency[char] = frequency.get(char, 0) + 1
    return frequency


def q3_first_non_repeating_character(word):
    """Q3. Return the first character that occurs exactly once, or None."""
    frequency = q2_character_frequency(word)
    for char in word:
        if frequency[char] == 1:
            return char
    return None


def q4_are_anagrams(s1, s2):
    """Q4. Return True if strings are anagrams, ignoring case and whitespace."""
    normalize = lambda value: sorted(ch.lower() for ch in value if not ch.isspace())
    return normalize(s1) == normalize(s2)


def q5_first_repeating_character(string):
    """Q5. Return the character whose second occurrence is encountered first."""
    seen = set()
    for char in string:
        if char in seen:
            return char
        seen.add(char)
    return None


def q6_move_zeros_to_end(nums):
    """Q6. Move zeros to the end while preserving non-zero order."""
    non_zeros = [num for num in nums if num != 0]
    return non_zeros + [0] * (len(nums) - len(non_zeros))


def q7_second_highest_distinct(nums):
    """Q7. Return the second-largest distinct number, or None."""
    distinct = sorted(set(nums), reverse=True)
    return distinct[1] if len(distinct) >= 2 else None


def q8_remove_duplicates_preserve_order(items):
    """Q8. Remove duplicates while preserving first occurrence order."""
    result = []
    seen = set()
    for item in items:
        if item not in seen:
            result.append(item)
            seen.add(item)
    return result


def q9_missing_number(nums, n):
    """Q9. Find the missing number from 1 through n."""
    return n * (n + 1) // 2 - sum(nums)


def q10_two_sum_first_pair(nums, target):
    """Q10. Return the first pair by second-element scan order, or []."""
    seen = set()
    for num in nums:
        needed = target - num
        if needed in seen:
            # The earlier matching value is the first one seen with this value.
            return [needed, num]
        seen.add(num)
    return []


def q11_closest_to_zero(nums):
    """Q11. Return the value closest to zero; prefer positive on a tie."""
    if not nums:
        return None
    return min(nums, key=lambda num: (abs(num), num < 0))


def q12_common_elements(list1, list2):
    """Q12. Return unique common values in first-list order."""
    values2 = set(list2)
    result = []
    seen = set()
    for item in list1:
        if item in values2 and item not in seen:
            result.append(item)
            seen.add(item)
    return result


def q13_rotate_right(nums, k):
    """Q13. Return a right-rotated copy of nums by k positions."""
    if not nums:
        return []
    k %= len(nums)
    if k == 0:
        return nums[:]
    return nums[-k:] + nums[:-k]


def q14_max_consecutive_pair_sum(nums):
    """Q14. Return the maximum sum of two adjacent elements."""
    return max(nums[i] + nums[i + 1] for i in range(len(nums) - 1))


def q15_all_unique_pairs_sum_target(nums, target):
    """Q15. Return unique target-sum pairs, sorted as specified."""
    seen = set()
    pairs = set()
    for num in nums:
        complement = target - num
        if complement in seen:
            pairs.add(tuple(sorted((num, complement))))
        seen.add(num)
    return [list(pair) for pair in sorted(pairs)]
