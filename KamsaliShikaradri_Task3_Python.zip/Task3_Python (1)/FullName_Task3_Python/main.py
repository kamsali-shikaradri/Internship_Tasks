# Task 3: Test all 15 functions from solutions.py
from solutions import (
    q1_word_frequency, q2_character_frequency,
    q3_first_non_repeating_character, q4_are_anagrams,
    q5_first_repeating_character, q6_move_zeros_to_end,
    q7_second_highest_distinct, q8_remove_duplicates_preserve_order,
    q9_missing_number, q10_two_sum_first_pair,
    q11_closest_to_zero, q12_common_elements,
    q13_rotate_right, q14_max_consecutive_pair_sum,
    q15_all_unique_pairs_sum_target
)

def show(question, function, given_input, extra_input):
    print(f"\n{question}")
    print("Given test:", function(*given_input) if isinstance(given_input, tuple) else function(given_input))
    print("Extra test:", function(*extra_input) if isinstance(extra_input, tuple) else function(extra_input))

show("Q1. Word frequency", q1_word_frequency,
     ("python is easy and python is powerful",), ("hello hello world",))
show("Q2. Character frequency", q2_character_frequency,
     ("banana",), ("apple",))
show("Q3. First non-repeating character", q3_first_non_repeating_character,
     ("swiss",), ("aabbc",))
show("Q4. Anagrams", q4_are_anagrams,
     ("listen", "silent"), ("hello", "world"))
show("Q5. First repeating character", q5_first_repeating_character,
     ("programming",), ("abcdefa",))
show("Q6. Move zeros to end", q6_move_zeros_to_end,
     ([0, 3, 0, 1, 2, 0, 4],), ([1, 0, 2],))
show("Q7. Second-highest distinct number", q7_second_highest_distinct,
     ([10, 20, 40, 30, 40, 20],), ([5, 5, 2],))
show("Q8. Remove duplicates", q8_remove_duplicates_preserve_order,
     ([4, 2, 4, 5, 2, 7, 5],), ([1, 1, 2, 3, 2],))
show("Q9. Missing number", q9_missing_number,
     ([1, 2, 4, 5, 6], 6), ([1, 3, 4], 4))
show("Q10. First two-sum pair", q10_two_sum_first_pair,
     ([2, 7, 11, 15], 9), ([1, 4, 2, 3], 5))
show("Q11. Closest to zero", q11_closest_to_zero,
     ([-8, -3, 2, 5, -2],), ([-4, -1, 1, 6],))
show("Q12. Common elements", q12_common_elements,
     ([1, 2, 3, 4, 5], [3, 4, 5, 6, 7]), ([4, 2, 4, 1], [1, 4]))
show("Q13. Rotate right", q13_rotate_right,
     ([1, 2, 3, 4, 5], 2), ([10, 20, 30], 1))
show("Q14. Maximum adjacent-pair sum", q14_max_consecutive_pair_sum,
     ([4, 7, 2, 9, 5],), ([1, 2, 3],))
show("Q15. All unique target-sum pairs", q15_all_unique_pairs_sum_target,
     ([2, 4, 3, 5, 7, 8, 1], 9), ([1, 1, 2, 3, 4], 5))
