 
# Problem: Check Strict Superset
# https://www.hackerrank.com/challenges/py-check-strict-superset/problem

a = set(map(int, input().split()))
number_of_sets = int(input())

result = True

for _ in range(number_of_sets):
    other = set(map(int, input().split()))

    if not a > other:
        result = False
        break

    # Consume any remaining input if an early failure occurs.
    # No additional processing is required for this challenge.

print(result)